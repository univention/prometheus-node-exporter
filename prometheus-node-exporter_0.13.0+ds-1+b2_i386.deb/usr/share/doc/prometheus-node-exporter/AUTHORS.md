The Prometheus project was started by Matt T. Proud (emeritus) and
Julius Volz in 2012.

Maintainers of this repository:

* Brian Brazil <brian.brazil@boxever.com>
* Johannes 'fish' Ziemke <github@freigeist.org>
* Tobias Schmidt <tobidt@gmail.com>

The following individuals have contributed code to this repository
(listed in alphabetical order):

* Alexey Palazhchenko <alexey.palazhchenko@gmail.com>
* Alexis Letessier
* Benjamin Staffin <benley@gmail.com>
* Björn Rabenstein <beorn@soundcloud.com>
* Brian Brazil <brian.brazil@boxever.com>
* Daniel Speichert <daniel@speichert.pro>
* Eric Ripa
* Fabian Reinartz <fabian@soundcloud.com>
* Franklin Wise <franklin@krave.io>
* Ian Hansen
* Ilia Choly <ilia.choly@gmail.com>
* Jari Takkala <jtakkala@gmail.com>
* Johannes 'fish' Ziemke <github@freigeist.org>
* Jonas Große Sundrup <cherti@letopolis.de>
* Julius Volz <julius.volz@gmail.com>
* Ken Herner <ken@modulus.io>
* Matthias Rampke <matthias@rampke.de>
* Siavash Safi <siavash.safi@gmail.com>
* Stephen Shirley <kormat@gmail.com>
* Steve Durrheimer <s.durrheimer@gmail.com>
* Tobias Schmidt <tobidt@gmail.com>
* Will Rouesnel <w.rouesnel@gmail.com>
